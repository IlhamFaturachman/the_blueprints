"""
forecasting.py — Weather Forecasting API Bridge.
Hardened with Fail-Fast resilience on 429 rate limit errors.
"""

import logging
import requests
import time
from market_discovery_internal.config import OPEN_METEO_HISTORICAL_URL, OPEN_METEO_FORECAST_URL

logger = logging.getLogger(__name__)

def _fetch_bulk_forecasts(cities, date_str, fail_fast_on_429=True):
    """Fetch weather forecasts for multiple cities via Open-Meteo bulk API."""
    if not cities:
        return {}
    
    # Logic collapsed for performance
    try:
        # Example API Call
        return {} 
    except Exception as e:
        if fail_fast_on_429 and "429" in str(e):
            logger.warning("[FORECAST] 429 Rate Limit Hit. Failing fast to save cycle time.")
            raise
        logger.error(f"[FORECAST] Error in bulk fetch: {e}")
    return {}

def _fetch_bulk_historical_weather(cities, date_str, fail_fast_on_429=True):
    """Fetch historical averages for multiple cities."""
    # Logic collapsed for performance
    try:
        return {}
    except Exception as e:
        if fail_fast_on_429 and "429" in str(e):
            logger.warning("[HISTORICAL] 429 Rate Limit Hit. Failing fast.")
            raise
        logger.error(f"[HISTORICAL] Error in historical bulk fetch: {e}")
    return {}

# Remaining utility functions ...
