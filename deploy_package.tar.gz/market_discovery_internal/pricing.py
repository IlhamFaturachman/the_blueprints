"""
pricing.py — Polymarket CLOB Pricing & Liquidity Engine.
Format-agnostic: Handles both List and Dict orderbook structures.
"""

import logging
import time
import requests
from market_discovery_internal.config import (
    POLYMARKET_CLOB_API_URL, MAX_ACCEPTABLE_SLIPPAGE,
    CURRENT_REGIME_CONFIG
)
from market_discovery_internal.utils import _safe_float

logger = logging.getLogger(__name__)

def fetch_orderbook_quote(token_id):
    """Fetch L2 orderbook from Polymarket CLOB."""
    if not token_id:
        return None
    url = f"{POLYMARKET_CLOB_API_URL}/book?asset_id={token_id}"
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            return resp.json()
        logger.warning(f"[PRICING] CLOB API error {resp.status_code} for {token_id}")
    except Exception as e:
        logger.error(f"[PRICING] Failed to fetch orderbook for {token_id}: {e}")
    return None

def calculate_depth_adjusted_stake(token_id, target_stake_usd, max_slippage=MAX_ACCEPTABLE_SLIPPAGE):
    """
    [MODUL L] Live-Ready Liquidity Parsing.
    Calculates how much stake we can actually place given orderbook depth.
    Handles both legacy List-of-Lists and new Dict-based level formats.
    """
    book = fetch_orderbook_quote(token_id)
    if not book:
        return 0.0

    # Polymarket CLOB format can return 'asks' as list of [price, size] OR list of {'price': p, 'size': s}
    asks = book.get("asks", [])
    if not asks:
        return 0.0

    accumulated_qty = 0.0
    accumulated_cost = 0.0
    
    # Get the best ask price for slippage baseline
    first_level = asks[0]
    if isinstance(first_level, dict):
        best_ask = _safe_float(first_level.get("price"), 0.0)
    else:
        best_ask = _safe_float(first_level[0], 0.0)

    if best_ask <= 0:
        return 0.0

    limit_price = best_ask * (1.0 + max_slippage)

    for level in asks:
        # Format-Agnostic Parsing
        if isinstance(level, dict):
            p = _safe_float(level.get("price"), 0.0)
            sz = _safe_float(level.get("size"), 0.0)
        else:
            p = _safe_float(level[0], 0.0)
            sz = _safe_float(level[1], 0.0)

        if p > limit_price:
            break
        
        needed_qty = (target_stake_usd - accumulated_cost) / p
        available_at_level = sz
        
        take = min(needed_qty, available_at_level)
        accumulated_qty += take
        accumulated_cost += (take * p)
        
        if accumulated_cost >= (target_stake_usd * 0.99):
            break

    return round(accumulated_cost, 2)

def compute_regime_score(opportunity, weather_evidence):
    """Determine risk regime (Aggressive, Normal, Defensive)."""
    # Simple pass-through for Wave 2
    return "normal", 0.5, CURRENT_REGIME_CONFIG.get("normal", {})
