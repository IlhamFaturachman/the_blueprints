import logging
import time
import os
import threading
from datetime import datetime, timezone
from market_discovery_internal.utils import _safe_float, _safe_div, _clamp, send_telegram_alert
from market_discovery_internal.config import (
    HYBRID_TAKE_PROFIT_MIN_PRICE, HYBRID_TAKE_PROFIT_MULTIPLIER,
    HYBRID_STOP_LOSS_MULTIPLIER, HYBRID_LATE_WINDOW_HOURS,
    HYBRID_MIN_CONFIDENCE_TO_HOLD, HYBRID_CONFIDENCE_EDGE_SCALE,
    PAPER_STAKE_USD, PAPER_BASE_WALLET, PAPER_MAX_OPEN_PER_CITY,
    MARKET_MAX_SPREAD_GATE, MAX_ACCEPTABLE_SLIPPAGE,
    MARKET_MIN_VOLUME_24HR
)
from market_discovery_internal.parsing import _normalize_city_key
from market_discovery_internal.analysis import decide_entry_bucket
from market_discovery_internal.database_manager import db
from market_discovery_internal.pricing import (
    calculate_depth_adjusted_stake, fetch_orderbook_quote, compute_regime_score
)
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger(__name__)

# [MODUL L] Heartbeat State
_HEARTBEAT_SENT = False
_heartbeat_lock = threading.Lock()
MIN_STAKE_THRESHOLD = 1.0 # Wave 2 dust filter

def parse_discovery_markets(
    markets_raw,
    *,
    parse_market_fn,
    max_spread=None,
    min_volume_24hr=None,
):
    """Parse raw markets and collect skip metrics used by discovery diagnostics."""
    _max_spread = max_spread if max_spread is not None else MARKET_MAX_SPREAD_GATE
    _min_vol = min_volume_24hr if min_volume_24hr is not None else MARKET_MIN_VOLUME_24HR

    parsed = []
    skipped_markets = 0
    exact_skipped = 0 
    daily_skip_reasons = {
        "daily_date_mismatch": 0,
        "daily_min_hours_not_met": 0,
        "too_close_to_resolve": 0,
    }

    for raw in markets_raw:
        parsed_result = parse_market_fn(raw, return_skip_reason=True)
        if isinstance(parsed_result, tuple) and len(parsed_result) == 2:
            parsed_market, skip_reason = parsed_result
        else:
            parsed_market = parsed_result
            skip_reason = None

        if not parsed_market:
            skipped_markets += 1
            if skip_reason in daily_skip_reasons:
                daily_skip_reasons[skip_reason] += 1
            continue

        if parsed_market["direction"] == "exact":
            spread = parsed_market.get("gamma_spread")
            vol24 = parsed_market.get("volume_24hr", 0.0)
            accepting = parsed_market.get("gamma_accepting_orders", True)
            best_ask = parsed_market.get("best_ask")

            if not accepting:
                exact_skipped += 1
                continue
            if best_ask is None or best_ask <= 0:
                exact_skipped += 1
                continue
            if spread is None or float(spread) > _max_spread:
                exact_skipped += 1
                continue
            if float(vol24) < _min_vol:
                exact_skipped += 1
                continue

        parsed.append(parsed_market)
    return parsed, skipped_markets, exact_skipped, daily_skip_reasons


def enrich_discovery_markets(
    parsed,
    *,
    perf_counter_fn,
    elapsed_ms_fn,
    prefetch_forecasts_fn,
    fetch_forecast_with_cache_fn,
    build_weather_evidence_fn,
    is_weather_evidence_valid_fn,
    calculate_edge_fn,
    maybe_apply_ai_decision_fn,
    resolve_station_with_ai_fn,
    discovery_forecast_prefetch_min_keys,
    discovery_forecast_prefetch_max_workers,
):
    """Enrich parsed markets with forecast/edge."""
    failed_cities = []
    failed_city_keys = set()
    enriched = []
    forecast_cache = {}
    forecast_cache_stats = {"hits": 0, "misses": 0}

    total_parsed = len(parsed)
    for i, market in enumerate(parsed, 1):
        if not market.get("icao_explicit"):
            ai_icao = resolve_station_with_ai_fn(market.get("city"), market.get("description"))
            if ai_icao:
                market["icao_code"] = ai_icao
                market["icao_explicit"] = True

    prefetch_started = perf_counter_fn()
    forecast_prefetch = prefetch_forecasts_fn(
        cache_keys=[(market.get("city"), market.get("date"), market.get("icao_code")) for market in parsed],
        cache=forecast_cache,
        min_keys=discovery_forecast_prefetch_min_keys,
        max_workers=discovery_forecast_prefetch_max_workers,
    )
    forecast_prefetch_ms = elapsed_ms_fn(prefetch_started)

    enrich_started = perf_counter_fn()
    for i, market in enumerate(parsed, 1):
        city = market["city"]
        date = market["date"]
        forecast_temp = fetch_forecast_with_cache_fn(
            city, date, forecast_cache,
            stats=forecast_cache_stats,
            icao_override=market.get("icao_code"),
        )
        evidence = build_weather_evidence_fn(city, date, forecast_temp)
        evidence_valid = is_weather_evidence_valid_fn(evidence)

        if forecast_temp is None:
            if city not in failed_city_keys:
                failed_city_keys.add(city)
                failed_cities.append(city)
            continue

        edge_result = calculate_edge_fn(market, forecast_temp)
        if edge_result:
            enriched_item = {**market, **edge_result}
            enriched_item["weather_evidence"] = evidence
            enriched_item["weather_evidence_valid"] = evidence_valid
            try:
                r_class, r_score, r_gates = compute_regime_score(enriched_item, evidence)
                enriched_item["regime_class"] = r_class
                enriched_item["regime_score"] = r_score
                enriched_item["regime_gates"] = r_gates
            except Exception:
                enriched_item["regime_class"] = "neutral"
                enriched_item["regime_score"] = 0.5
                enriched_item["regime_gates"] = {"min_prob": 0.72, "min_edge": 0.22, "max_price": 0.60}
            enriched.append(maybe_apply_ai_decision_fn(enriched_item))
    
    enrich_ms = elapsed_ms_fn(enrich_started)
    return {
        "enriched": enriched, "failed_cities": failed_cities,
        "forecast_cache": forecast_cache, "forecast_cache_stats": forecast_cache_stats,
        "forecast_prefetch": forecast_prefetch, "forecast_prefetch_ms": forecast_prefetch_ms,
        "enrich_ms": enrich_ms,
    }


def run_discovery_cycle(
    inspect=False, aggressive_scan=False, *,
    perf_counter_fn, elapsed_ms_fn, fetch_markets_fn,
    parse_discovery_markets_fn, enrich_discovery_markets_fn, filter_opportunities_fn,
    daily_resolve_only, daily_min_hours_to_resolve,
):
    cycle_started = perf_counter_fn()
    markets_raw = fetch_markets_fn(inspect=inspect, aggressive_scan=aggressive_scan)
    fetch_ms = elapsed_ms_fn(perf_counter_fn())

    parsed, skipped_markets, exact_skipped, daily_skip_reasons = parse_discovery_markets_fn(markets_raw)
    
    enrich_result = enrich_discovery_markets_fn(parsed)
    opportunities = filter_opportunities_fn(enrich_result["enriched"])
    
    performance = {
        "total_ms": elapsed_ms_fn(cycle_started),
        "fetch_markets_ms": fetch_ms,
        "forecast_prefetch_ms": enrich_result["forecast_prefetch_ms"],
        "enrich_ms": enrich_result["enrich_ms"],
        "forecast_cache": {
            "size": len(enrich_result["forecast_cache"]),
            "hits": enrich_result["forecast_cache_stats"]["hits"],
            "misses": enrich_result["forecast_cache_stats"]["misses"],
        }
    }

    return {
        "markets_raw": markets_raw, "parsed": parsed, "enriched": enrich_result["enriched"],
        "opportunities": opportunities, "performance": performance,
        "skipped_markets": skipped_markets, "exact_skipped": exact_skipped,
        "daily_skip_reasons": daily_skip_reasons, "failed_cities": enrich_result["failed_cities"]
    }


def build_open_position_inventory(open_positions):
    open_token_ids = {p.get("token_id") for p in open_positions if p.get("status") == "open"}
    open_city_counts = {}
    for p in open_positions:
        if p.get("status") == "open":
            ck = _normalize_city_key(p.get("city"))
            if ck: open_city_counts[ck] = open_city_counts.get(ck, 0) + 1
    return open_token_ids, open_city_counts


def build_entry_candidates(opportunities, open_token_ids, open_city_counts, min_bound, max_bound):
    bucket_counts = {"reject": 0, "watchlist": 0, "enter_swing": 0, "enter_hold_candidate": 0}
    entry_candidates = []
    seen_events = set()
    
    best_candidate_by_city = {}
    
    for opt in opportunities:
        bucket = decide_entry_bucket(opt, min_bound, max_bound)
        bn = bucket.get("bucket", "reject")
        bucket_counts[bn] = bucket_counts.get(bn, 0) + 1
        
        if bn not in {"enter_swing", "enter_hold_candidate"}: continue
        
        tid = str(opt.get("token_id"))
        if tid in open_token_ids: continue
        
        # Anti-Correlation
        ev_key = f"{opt.get('city')}-{opt.get('date')}-{opt.get('unit')}"
        if ev_key in seen_events: continue
        seen_events.add(ev_key)
        
        ck = _normalize_city_key(opt.get("city"))
        if ck and open_city_counts.get(ck, 0) >= PAPER_MAX_OPEN_PER_CITY: continue
        
        cand = {
            "city_key": ck, "opportunity": opt, "bucket": bucket, "bucket_name": bn,
            "rank": (bucket.get("confidence", 0), opt.get("edge", 0), -_safe_float(opt.get("yes_price"), 1))
        }
        
        if not ck:
            entry_candidates.append(cand)
        else:
            if ck not in best_candidate_by_city or cand["rank"] > best_candidate_by_city[ck]["rank"]:
                best_candidate_by_city[ck] = cand
                
    final_list = list(best_candidate_by_city.values()) + entry_candidates
    final_list.sort(key=lambda x: x["rank"], reverse=True)
    return final_list, bucket_counts, set(), set()


def append_opened_positions_from_candidates(
    entry_candidates, next_open_positions, open_token_ids, open_city_counts,
    available_slots, stake_usd, min_bound, max_bound, fetch_orderbook_quote_fn
):
    opened = []
    opened_keys = set()
    
    # [MODUL L] Parallel Liquidity Prefetching
    candidates_to_check = entry_candidates[:50]
    liquidity_cache = {}
    
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_tid = {
            executor.submit(calculate_depth_adjusted_stake, c["opportunity"].get("token_id"), stake_usd, MAX_ACCEPTABLE_SLIPPAGE): c["opportunity"].get("token_id")
            for c in candidates_to_check
        }
        for future in as_completed(future_to_tid):
            tid = str(future_to_tid[future])
            try: liquidity_cache[tid] = future.result()
            except: liquidity_cache[tid] = 0.0

    for cand in entry_candidates:
        if available_slots <= 0: break
        
        opt = cand["opportunity"]
        tid = str(opt.get("token_id"))
        dynamic_stake = liquidity_cache.get(tid)
        
        if dynamic_stake is None: # Fallback
            dynamic_stake = calculate_depth_adjusted_stake(tid, stake_usd, MAX_ACCEPTABLE_SLIPPAGE)
            
        if dynamic_stake < MIN_STAKE_THRESHOLD: continue
        
        ask = _safe_float(opt.get("best_ask"), 0.0)
        bid = _safe_float(opt.get("best_bid"), 0.0)
        
        if ask <= 0: # Live fetch failover
            q = fetch_orderbook_quote_fn(tid)
            ask = _safe_float(q.get("ask") if q else 0, 0)
            bid = _safe_float(q.get("bid") if q else 0, 0)
            
        if ask <= 0 or ask < min_bound or ask > max_bound: continue
        if ask > 0 and bid > 0 and (ask - bid) > MARKET_MAX_SPREAD_GATE: continue
        
        # Risk weighting
        conf = float(opt.get("model_prob", 0.70))
        risk_mult = max(0.5, min(1.5, conf / 0.70))
        final_stake = round(dynamic_stake * risk_mult, 2)
        if final_stake < MIN_STAKE_THRESHOLD: final_stake = dynamic_stake
        
        # Correlation cap
        if cand["city_key"] and open_city_counts.get(cand["city_key"], 0) >= 1:
            final_stake = round(final_stake * 0.70, 2)
            
        pos = build_paper_position({**opt, "entry_price": ask}, stake_usd=final_stake)
        pos.update({
            "entry_bucket": cand["bucket_name"], "entry_bucket_reason": cand["bucket"].get("reason"),
            "entry_confidence_score": cand["bucket"].get("confidence"),
            "risk_multiplier": risk_mult
        })
        
        next_open_positions.append(pos)
        opened.append(pos)
        open_token_ids.add(tid)
        if cand["city_key"]:
            open_city_counts[cand["city_key"]] = open_city_counts.get(cand["city_key"], 0) + 1
            opened_keys.add(cand["city_key"])
        available_slots -= 1
        
    return opened, opened_keys, available_slots


def build_paper_position(opportunity, stake_usd=PAPER_STAKE_USD):
    entry_price = _safe_float(opportunity.get("entry_price"), 0.0)
    qty = round(float(stake_usd) / (entry_price * 1.01), 6) # 1% slippage
    cost = round(qty * entry_price * 1.01, 4)
    tp = round(min(entry_price * 1.01 * HYBRID_TAKE_PROFIT_MULTIPLIER, 1.0), 4)
    
    return {
        "status": "open", "city": opportunity["city"], "token_id": opportunity["token_id"],
        "market_question": opportunity.get("market_question", ""), "direction": opportunity["direction"],
        "threshold": opportunity["threshold"], "unit": opportunity["unit"], "date": opportunity["date"],
        "end_date": opportunity.get("end_date"), "market_slug": opportunity.get("market_slug", ""),
        "entry_price": round(entry_price * 1.01, 4), "quantity": qty, "cost_basis": cost,
        "target_price": tp, "stop_loss_price": round(entry_price * 1.01 * HYBRID_STOP_LOSS_MULTIPLIER, 4),
        "entry_model_prob": opportunity.get("model_prob"), "opened_at": datetime.now(timezone.utc).isoformat()
    }


def evaluate_hybrid_exit(position, price, forecast_valid, hours=None, now_utc=None, confidence=None):
    ep = float(position.get("entry_price", price))
    tp = float(position.get("target_price", ep * 2))
    sl = float(position.get("stop_loss_price", ep * 0.7))
    peak = max(float(position.get("peak_price", price)), price)
    
    if price <= sl: return {"action": "sell", "reason": "stop_loss", "peak_price": peak}
    if price >= tp: return {"action": "sell", "reason": "take_profit", "peak_price": peak}
    
    # Trailing Stop: 15% drop from 20% profit peak
    if ep > 0 and peak >= ep * 1.20 and price < peak * 0.85:
        return {"action": "sell", "reason": "trailing_stop", "peak_price": peak}
        
    if hours is not None and hours <= 2.0 and not forecast_valid:
        return {"action": "sell", "reason": "thesis_decay", "peak_price": peak}
        
    return {"action": "hold", "reason": "await_target", "peak_price": peak}


def close_paper_position(position, price, reason, now_utc=None):
    closed = {**position}
    val = round(price * float(closed["quantity"]), 4)
    pnl = round(val - float(closed["cost_basis"]), 4)
    closed.update({
        "status": "closed", "exit_price": price, "realized_pnl_usd": pnl,
        "closed_at": (now_utc or datetime.now(timezone.utc)).isoformat(), "close_reason": reason
    })
    db.record_trade_history(closed)
    return closed

def update_paper_position(position, price, forecast_valid, hours=None, now_utc=None, confidence=None):
    decision = evaluate_hybrid_exit(position, price, forecast_valid, hours, now_utc, confidence)
    updated = {**position, "last_price": price, "peak_price": decision.get("peak_price")}
    if decision["action"] == "sell":
        updated = close_paper_position(updated, price, decision["reason"], now_utc)
    return updated, decision
